//settings

bool sittings(){
tft.fillScreen(WHITE);
  for (int i = 255; i >= -0; i = i - 1) {
     col[0] = tft.color565(i, i, i);
    tft.drawRect(0,0,i,i,col[0]);
   }
  
  Fon_btn.initButton(&tft,  40, 20, 56, 35, WHITE, WHITE, BLACK, "OFF", 2);
 Fon_btn.drawButton(false);
Foff_btn.initButton(&tft, 40, 75, 56, 35, WHITE, WHITE, BLACK, "REL", 2);
 Foff_btn.drawButton(false);

tft.setCursor(10, 160);
       tft.setTextColor(WHITE);
  tft.setTextSize(2);
 tft.println("SD not found"); 
tft.setCursor(10, 140);
tft.println("DINAMIC not found"); 
tft.setCursor(10, 190);
tft.println("bytes 30462= max 32256"); 
while(1){

if (++ss > 59) {
            ss = 0;
            mm++;
            if (mm > 59) {
                mm = 0;
                hh++;
                if (hh > 23) hh = 0;
         //   delay(950);
            }
        }
        char buf[20];
        col[1] = tft.color565(180, 0, 180);
        tft.fillRect(0, 210, 190, 30, WHITE);  
       // tft.fillScreen(BLACK);
  tft.setTextColor(BLACK);
        tft.setTextSize(4);
        sprintf(buf, "%02d:%02d:%02d", hh, mm, ss);
        //tft.drawCircle(120, 150, 119, BLUE);
        tft.setCursor(0, 210);
        tft.print(buf);


bool down = Touch_getXY();
    Fon_btn.press(down && Fon_btn.contains(px, py));
Foff_btn.press(down && Foff_btn.contains(px, py));

if (Foff_btn.justReleased())
       Foff_btn.drawButton(false);
if (Foff_btn.justPressed()) {
       Foff_btn.drawButton(true);
tft.fillScreen(WHITE);
tft.setCursor(110, 70);
       tft.setTextColor(BLACK);
  tft.setTextSize(2);
 tft.println("TeachTouch"); 
tft.setCursor(110, 90);
tft.println("RELOADING."); 
 delay(5000);
tft.fillScreen(BLACK);
delay(3000);
void (*reboot)(void) = 0; reboot();
    }



if (Fon_btn.justReleased())
       Fon_btn.drawButton(false);
if (Fon_btn.justPressed()) {
       Fon_btn.drawButton(true);
tft.fillScreen(BLACK);
tft.setCursor(110, 70);
       tft.setTextColor(WHITE);
  tft.setTextSize(2);
 tft.println("TeachTouch"); 

 delay(5000);
tft.fillScreen(BLACK);
while(1){}
}




   delay(950);
    }




}
