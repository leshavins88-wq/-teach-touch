int pixel_x, pixel_y;     //Touch_getXY() updates global vars
bool Touch_XY(void)
{
    TSPoint p = ts.getPoint();
    pinMode(YP, OUTPUT);      //restore shared pins
    pinMode(XM, OUTPUT);
    digitalWrite(YP, HIGH);   //because TFT control pins
    digitalWrite(XM, HIGH);
    bool pressed = (p.z > MINPRESSURE && p.z < MAXPRESSURE);
    if (pressed) {
        pixel_x = map(p.x, TS_RT, TS_LEFT, 0, tft.width()); 
        pixel_y = map(p.y, TS_TOP, TS_BOT, 0, tft.height());
    }
    return pressed;
}

bool sent(){
//void setup
tft.fillScreen(WHITE);
tft.setRotation(1);
for (int i = 555; i >= -0; i = i - 1) {
     col[0] = tft.color565(i, i, i);
    tft.drawRoundRect(0,0,i,i,i,col[0]);
   }

Hon_btn.initButton(&tft,  180, 60, 50, 50, RED, RED, BLACK, "WPS", 2);
 Hon_btn.drawButton(false);
 Loff_btn.initButton(&tft, 40, 60, 50, 50, BLUE, BLUE, BLACK, "getry das", 1);
   Loff_btn.drawButton(false);
 Bon_btn.initButton(&tft,  190, 40, 50, 50, BLUE, BLUE, BLACK, "tap", 2);
tft.setCursor(10, 90);
       tft.setTextColor(BLACK);
  tft.setTextSize(1);
tft.println("SD CARD NOT FOUND!!! WARNING NOT MEMORY!!! ");


//void loop
while(1){
bool down = Touch_getXY();
Hon_btn.press(down && Hon_btn.contains(px, py)); 
Loff_btn.press(down && Loff_btn.contains(px, py)); 
Bon_btn.press(down && Bon_btn.contains(pixel_x, pixel_y)); 
//tft.setRotation(0);

 
  


 if (Hon_btn.justPressed()) {    
  tft.fillScreen(GREY);
tft.setRotation(0);
   tft.setCursor(10, 20);
       tft.setTextColor(BLACK);
  tft.setTextSize(2);
tft.println("DISPLAY");
 tft.setCursor(10, 40);    
  tft.setTextSize(1);
tft.println("The 2.4 inch display has a slot for the SD card");
  tft.setCursor(10, 60);
  tft.setTextSize(1);
tft.println("The display has a touch shield on 4 cantacts. The name of the display is 2.4 TFT LCD SHIELD. it has two controllers."); 
   tft.setCursor(10, 100);   
  tft.setTextSize(2);
tft.println("ARDUINO");   
  tft.setCursor(10, 120);  
  tft.setTextSize(1);
tft.println("arduino uno is the most important component for the operation and withdrawal of corticosteroids. you need to have an Arduino application for it, because the entire program is downloaded to it. arduino uno version.");    
tft.setCursor(10, 180); 
  tft.setTextSize(2);
tft.println("libraries");
tft.setCursor(10, 200);  
  tft.setTextSize(1);
tft.println("library Adafruit_GFX,library MCUFRIEND_kbv,library TouchScreen. ");
tft.setCursor(10, 220);     
  tft.setTextSize(2);
tft.println("sketch");
tft.setCursor(10, 240);      
  tft.setTextSize(1);
tft.println("the maximum arduino can hold 32256 bytes. The sketch requires 30462 bytes"); 
  while(1){}
    
    }



 

    if (Loff_btn.justPressed()) {
/*while(1){
    Touch_XY();
     if (Bon_btn.justPressed()) {*/
     
      
       tft.setRotation(0);

      
       Bon_btn.initButton(&tft,  190, 40, 50, 50, BLUE, BLUE, BLACK, "tap", 2);

       
       tft.fillScreen(BLUE);  
          
        tft.setCursor(55, 290);
       tft.setTextColor(BLACK);
  tft.setTextSize(4);
  tft.println(">");
            
        tft.fillRect(0, 0, 60, 330, GREEN);  
       tft.fillRect(60, 50, 40, 40, BLACK);
    delay(200);


             tft.setCursor(55, 290);
       tft.setTextColor(BLUE);
  tft.setTextSize(4);
  tft.println(">");
            
        tft.fillRect(0, 0, 60, 330, BLUE);  
       tft.fillRect(60, 50, 40, 40, BLUE);
      // tft.fillScreen(BLUE);  
          
        tft.setCursor(55, 210);
       tft.setTextColor(BLACK);
  tft.setTextSize(4);
  tft.println(">");
            
        tft.fillRect(0, 0, 60, 330, GREEN);  
       tft.fillRect(60, 50, 40, 40, BLACK);
       
        delay(200);

             tft.setCursor(55, 210);
       tft.setTextColor(BLUE);
  tft.setTextSize(4);
  tft.println(">");
            
        tft.fillRect(0, 0, 60, 330, BLUE);  
       tft.fillRect(60, 50, 40, 40, BLUE);
      // tft.fillScreen(BLUE);  
          
        tft.setCursor(55, 150);
       tft.setTextColor(BLACK);
  tft.setTextSize(4);
  tft.println(">");
            
        tft.fillRect(0, 0, 60, 330, GREEN);  
       tft.fillRect(90, 50, 40, 40, BLACK);
       
      delay(200);


                  tft.setCursor(55, 150);
       tft.setTextColor(BLUE);
  tft.setTextSize(4);
  tft.println(">");
            
        tft.fillRect(0, 0, 60, 330, BLUE);  
       tft.fillRect(90, 50, 40, 40, BLUE);
      // tft.fillScreen(BLUE);  
          
        tft.setCursor(55, 100);
       tft.setTextColor(BLACK);
  tft.setTextSize(4);
  tft.println(">");
            
        tft.fillRect(0, 0, 60, 330, GREEN);  
       tft.fillRect(150, 50, 40, 40, BLACK);
        
        delay(200);
            tft.setCursor(55, 100);
       tft.setTextColor(BLUE);
  tft.setTextSize(4);
  tft.println(">");
            
        tft.fillRect(0, 0, 60, 330, BLUE);  
       tft.fillRect(150, 50, 40, 40, BLUE);
       //tft.fillScreen(BLUE);  
          
        tft.setCursor(55, 50);
       tft.setTextColor(BLACK);
  tft.setTextSize(4);
  tft.println(">");
            
        tft.fillRect(0, 0, 60, 330, GREEN);  
       tft.fillRect(90, 50, 40, 40, BLACK);
        
        delay(200);
             tft.setCursor(55, 50);
       tft.setTextColor(BLUE);
  tft.setTextSize(4);
  tft.println(">");
            
        tft.fillRect(0, 0, 60, 330, BLUE);  
       tft.fillRect(90, 50, 40, 40, BLUE);
      // tft.fillScreen(BLUE);  
          
        tft.setCursor(55, 0);
       tft.setTextColor(BLACK);
  tft.setTextSize(4);
  tft.println(">");
            
        tft.fillRect(0, 0, 60, 330, GREEN);  
       tft.fillRect(60, 50, 40, 40, BLACK);
        
           delay(200);
            tft.setCursor(55, 0);
       tft.setTextColor(BLUE);
  tft.setTextSize(4);
  tft.println(">");
            
        tft.fillRect(0, 0, 60, 330, BLUE);  
       tft.fillRect(60, 50, 40, 40, BLUE);
       tft.fillScreen(BLUE);  
          
    
            
        tft.fillRect(0, 0, 60, 330, GREEN);  
       tft.fillRect(60, 50, 40, 40, BLACK);
        
        Loff_btn.drawButton(true);
    

    /* }
    }*/
    
}

}
}
