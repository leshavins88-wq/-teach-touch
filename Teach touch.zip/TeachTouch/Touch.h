//include touch


#include <TouchScreen.h>
//#define MINPRESSURE 500
//#define MAXPRESSURE 1000
const int XP=8,XM=A2,YP=A3,YM=9; //ID=0x9341
const int TS_LEFT = 907, TS_RT = 136, TS_TOP = 942, TS_BOT = 139;

TouchScreen ts = TouchScreen(XP, YP, XM, YM, 300);

Adafruit_GFX_Button  Fon_btn, Foff_btn ,Bon_btn, Boff_btn, Loff_btn, Hon_btn;

int px, py;     //Touch_getXY() updates global vars
bool Touch_getXY(void)
{
    TSPoint p = ts.getPoint();
    pinMode(YP, OUTPUT);      //restore shared pins
    pinMode(XM, OUTPUT);
    digitalWrite(YP, HIGH);   //because TFT control pins
    digitalWrite(XM, HIGH);
    bool pressed = (p.z > MINPRESSURE && p.z < MAXPRESSURE);
    if (pressed) {
        py = map(p.x, TS_LEFT, TS_RT, 0, tft.width()); 
        //py = map(p.x, TS_RT, TS_LEFT, 0, tft.width()); 
        px = map(p.y, TS_TOP, TS_BOT, 0, tft.height());
    }
    return pressed;
}




#define TS_MINX 150
#define TS_MINY 120
#define TS_MAXX 920
#define TS_MAXY 940
