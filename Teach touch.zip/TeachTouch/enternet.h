//sorry arduino not wifi
bool enternet(){
tft.fillScreen(WHITE);
for (int i = 255; i >= -0; i = i - 1) {
     col[0] = tft.color565(i, i, i);
    tft.drawRect(0,0,i,i,col[0]);
   }
   tft.drawBitmap(140,85,LOAD,50,55,BLACK);
delay(5000);
tft.setCursor(10, 10);
       tft.setTextColor(BLACK);
  tft.setTextSize(1);
 tft.println("Sorry wifi not found"); 
delay(3000);
void (*reboot)(void) = 0; reboot();
}
