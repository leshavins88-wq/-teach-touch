#include <Adafruit_GFX.h>
//#include <Adafruit_TFTLCD.h> // Hardware-specific library
#include <MCUFRIEND_kbv.h>
MCUFRIEND_kbv tft;
#define MINPRESSURE 10
#define MAXPRESSURE 1000





#define LCD_CS A3
#define LCD_CD A2
#define LCD_WR A1
#define LCD_RD A0
// optional
#define LCD_RESET A4

//Adafruit_TFTLCD tft(LCD_CS, LCD_CD, LCD_WR, LCD_RD, LCD_RESET);
uint16_t ID;
//Adafruit_TFTLCD tft(LCD_CS, LCD_CD, LCD_WR, LCD_RD, LCD_RESET);
#include "images.h"
#include "Touch.h"
#include "colors.h"
#include "Time.h"


#include "paint.h"
#include "enternet.h"
#include "sittings.h"
#include "sent.h"

void setup() {
  // put your setup code here, to run once:
 Serial.begin(9600);
    uint16_t ID = tft.readID();
    Serial.print("TFT ID = 0x");
    Serial.println(ID, HEX);
    Serial.println("Calibrate for your Touch Panel");
    if (ID == 0xD3D3) ID = 0x9486; // write-only shield
    tft.reset();
    tft.begin(ID);
    tft.setRotation(1);            //PORTRAIT
    tft.fillScreen(BLACK);
     hh = conv2d(__TIME__);
    mm = conv2d(__TIME__ + 3);
    ss = conv2d(__TIME__ + 6);

//______________________________________________________________
 Fon_btn.initButton(&tft,  274, 20, 56, 35, WHITE, WHITE, WHITE, "", 2);
 Fon_btn.drawButton(false);
 Foff_btn.initButton(&tft, 274, 75, 56, 35, WHITE, WHITE, WHITE, "", 2);
 Foff_btn.drawButton(false);
 Bon_btn.initButton(&tft,  274, 140, 56, 35, WHITE, WHITE, WHITE, "", 2);
 Bon_btn.drawButton(false);
 Boff_btn.initButton(&tft, 274, 200, 56, 35, WHITE, WHITE, WHITE, "", 2);
 Boff_btn.drawButton(false);

 
}

void loop () {

menu();

//START();
}


void menu() {
// put your main code here, to run repeatedly:
for (int i = 355; i >= -0; i = i - 1) {
     col[0] = tft.color565(i, i, i);
     tft.drawRect(i,0,1,320,col[0]);
   }
   for (int i = 255; i >= -0; i = i - 1) {
     col[0] = tft.color565(i, i, i);
    tft.drawRoundRect(i,i,i,i,i,col[0]);
   }

tft.setCursor(110, 70);
       tft.setTextColor(WHITE);
  tft.setTextSize(2);
 tft.println("TeachTouch"); 
tft.drawBitmap(264,5,PENC,50,35,WHITE);
tft.drawBitmap(264,60,INIT,56,35,WHITE);
tft.drawBitmap(264,125,HACTP,45,46,WHITE);
tft.drawBitmap(264,191,DOWL,45,46,WHITE);
while (1) {
       if (++ss > 59) {
            ss = 0;
            mm++;
            if (mm > 59) {
                mm = 0;
                hh++;
                if (hh > 23) hh = 0;
         //   delay(950);
            }
        }
        char buf[20];
        col[1] = tft.color565(180, 0, 180);
        tft.fillRect(70, 90, 190, 30, BLACK);  
       // tft.fillScreen(BLACK);
  tft.setTextColor(WHITE);
        tft.setTextSize(4);
        sprintf(buf, "%02d:%02d:%02d", hh, mm, ss);
        //tft.drawCircle(120, 150, 119, BLUE);
        tft.setCursor(70, 90);
        tft.print(buf);
    
    bool down = Touch_getXY();
    Fon_btn.press(down && Fon_btn.contains(px, py));
    Foff_btn.press(down && Foff_btn.contains(px, py));
    Bon_btn.press(down && Bon_btn.contains(px, py));
    Boff_btn.press(down && Boff_btn.contains(px, py));


if (Fon_btn.justReleased())
       Fon_btn.drawButton(false);
if (Fon_btn.justPressed()) {
       Fon_btn.drawButton(true);
paint();
    }

if (Foff_btn.justReleased())
       Foff_btn.drawButton(false);
if (Foff_btn.justPressed()) {
       Foff_btn.drawButton(true);
enternet();
    }

if (Bon_btn.justReleased())
       Bon_btn.drawButton(false);
if (Bon_btn.justPressed()) {
       Bon_btn.drawButton(true);
sittings();
    }

if (Boff_btn.justReleased())
       Boff_btn.drawButton(false);
if (Boff_btn.justPressed()) {
       Boff_btn.drawButton(true);
sent();
    }

        
        delay(950);
    
    }
}
